let allData = [];
let playing = false;
let timer = null;

const tooltip = d3.select("#tooltip");

// LOAD DATA
d3.csv("data/shots_2024.csv").then(raw => {

    allData = raw.map(d => ({
        ...d,
        LOC_X: +d.LOC_X,
        LOC_Y: +d.LOC_Y,
        SHOT_DISTANCE: +d.SHOT_DISTANCE,
        QUARTER: +d.QUARTER,

        SHOT_MADE:
            d.SHOT_MADE === true ||
            d.SHOT_MADE === "true" ||
            d.SHOT_MADE === "True" ||
            d.SHOT_MADE === "TRUE",

        PLAYER_NAME: String(d.PLAYER_NAME || "").trim(),
        SHOT_TYPE: String(d.SHOT_TYPE || "").trim(),
        BASIC_ZONE: String(d.BASIC_ZONE || "").trim(),
        ZONE_NAME: String(d.ZONE_NAME || "").trim()

    })).filter(d =>
        d.PLAYER_NAME &&
        d.SHOT_TYPE === "3PT Field Goal" &&
        Number.isFinite(d.LOC_X) &&
        Number.isFinite(d.LOC_Y) &&
        Number.isFinite(d.SHOT_DISTANCE) &&
        d.LOC_Y <= 47
    );

    populatePlayers();
    bindEvents();
    update();
});

// PLAYERS
function populatePlayers() {

    const players = Array.from(
        new Set(allData.map(d => d.PLAYER_NAME))
    ).sort();

    d3.select("#player1")
        .selectAll("option")
        .data(players)
        .join("option")
        .attr("value", d => d)
        .text(d => d);

    d3.select("#player2")
        .selectAll("option")
        .data(players)
        .join("option")
        .attr("value", d => d)
        .text(d => d);

    if (players.includes("Stephen Curry")) {
        d3.select("#player1").property("value", "Stephen Curry");
    }

    if (players.includes("Luka Doncic")) {
        d3.select("#player2").property("value", "Luka Doncic");
    } else if (players.length > 1) {
        d3.select("#player2").property("value", players[1]);
    }
}

// EVENTS
function bindEvents() {
    d3.select("#player1").on("change", update);
    d3.select("#player2").on("change", update);
    d3.select("#quarter").on("change", update);
    d3.select("#sortMode").on("change", update);
    d3.select("#shotView").on("change", update);
    d3.select("#playBtn").on("click", toggleAnimation);
}

// UPDATE
function update() {

    const player1 = d3.select("#player1").property("value");
    const player2 = d3.select("#player2").property("value");
    const quarter = d3.select("#quarter").property("value");
    const sortMode = d3.select("#sortMode").property("value");
    const shotView = d3.select("#shotView").property("value");

    d3.select("#player1Title").text(`Igrač: ${player1}`);
    d3.select("#player2Title").text(`Igrač: ${player2}`);
    d3.select("#scatter1Label").text(player1);
    d3.select("#scatter2Label").text(player2);

    const baseShots1 = filterShots(player1, quarter);
    const baseShots2 = filterShots(player2, quarter);

    const visibleShots1 = filterByShotView(baseShots1, shotView);
    const visibleShots2 = filterByShotView(baseShots2, shotView);

    drawCourt(d3.select("#court1"), sample(visibleShots1, 1200));
    drawCourt(d3.select("#court2"), sample(visibleShots2, 1200));

    drawBarChart(baseShots1, baseShots2, player1, player2, sortMode);

    drawLineChart(player1, player2);

    drawDistanceHistogram(
        d3.select("#scatter1"),
        visibleShots1,
        player1,
        "#38bdf8",
        shotView
    );

    drawDistanceHistogram(
        d3.select("#scatter2"),
        visibleShots2,
        player2,
        "#f97316",
        shotView
    );

    drawLineChart(player1, player2, shotView);

    updateStats(baseShots1, baseShots2, player1, player2);
}

// FILTERS
function filterShots(player, quarter) {
    return allData.filter(d =>
        d.PLAYER_NAME === player &&
        (
            quarter === "all" ||
            d.QUARTER === +quarter
        )
    );
}

function filterByShotView(shots, shotView) {
    if (shotView === "made") {
        return shots.filter(d => d.SHOT_MADE);
    }

    if (shotView === "missed") {
        return shots.filter(d => !d.SHOT_MADE);
    }

    return shots;
}

function getShotViewLabel(shotView) {
    if (shotView === "made") return "pogoci";
    if (shotView === "missed") return "promašaji";
    return "pokušaji";
}

// COURT
function setupCourt(svg) {

    svg
        .attr("viewBox", "-26 -1 52 49")
        .attr("preserveAspectRatio", "xMidYMid meet");

    const root = svg.selectAll(".court-root")
        .data([null])
        .join("g")
        .attr("class", "court-root")
        .attr("transform", "translate(0,47) scale(1,-1)");

    root.selectAll(".court-bg")
        .data([null])
        .join("rect")
        .attr("class", "court-bg")
        .attr("x", -26)
        .attr("y", -1)
        .attr("width", 52)
        .attr("height", 49);

    const lines = [
        { type: "rect", x: -25, y: 0, w: 50, h: 47 },
        { type: "rect", x: -8, y: 28, w: 16, h: 19 },
        { type: "line", x1: -3, y1: 43.2, x2: 3, y2: 43.2 },
        { type: "circle", cx: 0, cy: 41.75, r: 0.75 },
        { type: "circle", cx: 0, cy: 28, r: 6 },
        { type: "line", x1: -22, y1: 47, x2: -22, y2: 32.8 },
        { type: "line", x1: 22, y1: 47, x2: 22, y2: 32.8 },
        { type: "path", d: "M -22 32.8 A 23.75 23.75 0 0 1 22 32.8" },
        { type: "path", d: "M -6 0 A 6 6 0 0 0 6 0" }
    ];

    const courtLines = root.selectAll(".court-shape")
        .data(lines)
        .join(function(enter) {
            return enter.append(d => {
                if (d.type === "rect") return document.createElementNS("http://www.w3.org/2000/svg", "rect");
                if (d.type === "line") return document.createElementNS("http://www.w3.org/2000/svg", "line");
                if (d.type === "circle") return document.createElementNS("http://www.w3.org/2000/svg", "circle");
                return document.createElementNS("http://www.w3.org/2000/svg", "path");
            });
        })
        .attr("class", "court-shape court-line");

    courtLines.each(function(d) {
        const el = d3.select(this);

        if (d.type === "rect") {
            el.attr("x", d.x)
                .attr("y", d.y)
                .attr("width", d.w)
                .attr("height", d.h);
        }

        if (d.type === "line") {
            el.attr("x1", d.x1)
                .attr("y1", d.y1)
                .attr("x2", d.x2)
                .attr("y2", d.y2);
        }

        if (d.type === "circle") {
            el.attr("cx", d.cx)
                .attr("cy", d.cy)
                .attr("r", d.r);
        }

        if (d.type === "path") {
            el.attr("d", d.d);
        }
    });

    root.selectAll(".shots-layer")
        .data([null])
        .join("g")
        .attr("class", "shots-layer");
}

function drawCourt(svg, shots) {

    setupCourt(svg);

    const layer = svg.select(".shots-layer");

    layer.selectAll(".shot")
        .data(shots, d => `${d.GAME_ID}-${d.PLAYER_ID}-${d.LOC_X}-${d.LOC_Y}-${d.SHOT_NUMBER}`)
        .join(
            enter => enter.append("circle")
                .attr("class", "shot")
                .attr("cx", d => d.LOC_X)
                .attr("cy", d => 47 - d.LOC_Y)
                .attr("r", 0),
            update => update,
            exit => exit.transition()
                .duration(300)
                .attr("r", 0)
                .remove()
        )
        .attr("fill", d => d.SHOT_MADE ? "#22c55e" : "#ef4444")
        .attr("opacity", 0.82)
        .on("mouseover", function(event, d) {
            d3.select(this).attr("r", 0.75);

            showTooltip(event, `
                <strong>${d.PLAYER_NAME}</strong><br>
                ${d.SHOT_MADE ? "Pogodak" : "Promašaj"}<br>
                Udaljenost: ${d.SHOT_DISTANCE} ft<br>
                Četvrtina: ${d.QUARTER}<br>
                Zona: ${getZone(d)}
            `);
        })
        .on("mousemove", moveTooltip)
        .on("mouseleave", function() {
            d3.select(this).attr("r", 0.38);
            hideTooltip();
        })
        .transition()
        .duration(650)
        .attr("cx", d => d.LOC_X)
        .attr("cy", d => 47 - d.LOC_Y)
        .attr("r", 0.38);
}

// ZONES
function getZone(d) {
    if (d.BASIC_ZONE.includes("Left Corner")) return "Left Corner";
    if (d.BASIC_ZONE.includes("Right Corner")) return "Right Corner";
    if (d.ZONE_NAME === "Left Side Center") return "Left Wing";
    if (d.ZONE_NAME === "Right Side Center") return "Right Wing";
    if (d.ZONE_NAME === "Center") return "Top";

    return "Other";
}

function calcZoneStats(shots) {

    const zones = [
        "Left Corner",
        "Right Corner",
        "Left Wing",
        "Right Wing",
        "Top"
    ];

    return zones.map(zone => {

        const zoneShots = shots.filter(d => getZone(d) === zone);
        const attempts = zoneShots.length;
        const made = zoneShots.filter(d => d.SHOT_MADE).length;

        return {
            zone,
            attempts,
            made,
            missed: attempts - made,
            percentage: attempts ? (made / attempts) * 100 : 0
        };
    });
}

// BAR CHART
function drawBarChart(shots1, shots2, player1, player2, sortMode, shotView) {

    const svg = d3.select("#barChart");

    svg.selectAll("*").remove();

    const width = 900;
    const height = 450;

    svg.attr("viewBox", `0 0 ${width} ${height}`);

    let p1 = calcZoneStats(shots1);
    let p2 = calcZoneStats(shots2);

    p1.sort((a, b) => b[sortMode] - a[sortMode]);

    const zoneOrder = p1.map(d => d.zone);

    p2.sort((a, b) =>
        zoneOrder.indexOf(a.zone) -
        zoneOrder.indexOf(b.zone)
    );

    const combined = [];

    p1.forEach(d => {
        combined.push({
            ...d,
            player: player1,
            key: "p1"
        });
    });

    p2.forEach(d => {
        combined.push({
            ...d,
            player: player2,
            key: "p2"
        });
    });

    const x0 = d3.scaleBand()
        .domain(zoneOrder)
        .range([80, 820])
        .padding(0.2);

    const x1 = d3.scaleBand()
        .domain(["p1", "p2"])
        .range([0, x0.bandwidth()])
        .padding(0.12);

    const yMax = sortMode === "percentage"
        ? 100
        : Math.max(1, d3.max(combined, d => d[sortMode]));

    const y = d3.scaleLinear()
        .domain([0, yMax])
        .nice()
        .range([360, 50]);

    svg.append("g")
        .attr("transform", "translate(0,360)")
        .attr("class", "axis")
        .call(d3.axisBottom(x0));

    svg.append("g")
        .attr("transform", "translate(80,0)")
        .attr("class", "axis")
        .call(
            d3.axisLeft(y)
                .tickFormat(d => sortMode === "percentage" ? `${d}%` : d)
        );

    svg.selectAll(".bar")
        .data(combined, d => d.zone + d.key)
        .join(
            enter => enter.append("rect")
                .attr("class", "bar")
                .attr("x", d => x0(d.zone) + x1(d.key))
                .attr("y", 360)
                .attr("width", x1.bandwidth())
                .attr("height", 0)
                .attr("rx", 10),
            update => update,
            exit => exit.remove()
        )
        .attr("fill", d => d.key === "p1" ? "#38bdf8" : "#f97316")
        .on("mouseover", function(event, d) {
            d3.select(this).attr("opacity", 0.8);

            showTooltip(event, `
                <strong>${d.player}</strong><br>
                Zona: ${d.zone}<br>
                Pokušaji: ${d.attempts}<br>
                Pogoci: ${d.made}<br>
                Promašaji: ${d.missed}<br>
                Postotak: ${d.percentage.toFixed(1)}%
            `);
        })
        .on("mousemove", moveTooltip)
        .on("mouseleave", function() {
            d3.select(this).attr("opacity", 1);
            hideTooltip();
        })
        .transition()
        .duration(800)
        .attr("x", d => x0(d.zone) + x1(d.key))
        .attr("width", x1.bandwidth())
        .attr("y", d => y(d[sortMode]))
        .attr("height", d => 360 - y(d[sortMode]));

    svg.append("text")
        .attr("x", 80)
        .attr("y", 30)
        .attr("fill", "white")
        .attr("font-size", 14)
        

    svg.append("text")
        .attr("x", 80)
        .attr("y", 30)
        .attr("fill", "white")
        .attr("font-size", 14)
        
    const legend = svg.append("g")
        .attr("transform", "translate(650,35)");

    legend.append("rect")
        .attr("width", 18)
        .attr("height", 18)
        .attr("fill", "#38bdf8");

    legend.append("text")
        .attr("x", 28)
        .attr("y", 14)
        .text(player1)
        .attr("fill", "white");

    legend.append("rect")
        .attr("y", 28)
        .attr("width", 18)
        .attr("height", 18)
        .attr("fill", "#f97316");

    legend.append("text")
        .attr("x", 28)
        .attr("y", 42)
        .text(player2)
        .attr("fill", "white");
}

// DISTANCE HISTOGRAM
function drawDistanceHistogram(svg, shots, player, color, shotView) {

    svg.selectAll("*").remove();

    const width = 760;
    const height = 420;
    const margin = { top: 35, right: 30, bottom: 70, left: 70 };

    svg.attr("viewBox", `0 0 ${width} ${height}`);

    const bins = d3.bin()
        .value(d => d.SHOT_DISTANCE)
        .domain([20, 38])
        .thresholds(d3.range(20, 39, 1))(shots);

    const data = bins.map(bin => {
        const count = bin.length;
        const made = bin.filter(d => d.SHOT_MADE).length;

        return {
            distance: `${Math.round(bin.x0)}-${Math.round(bin.x1)} ft`,
            count,
            made,
            missed: count - made,
            percentage: count ? (made / count) * 100 : 0
        };
    });

    const x = d3.scaleBand()
        .domain(data.map(d => d.distance))
        .range([margin.left, width - margin.right])
        .padding(0.15);

    const y = d3.scaleLinear()
        .domain([0, d3.max(data, d => d.count) || 1])
        .nice()
        .range([height - margin.bottom, margin.top]);

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x))
        .selectAll("text")
        .attr("transform", "rotate(-35)")
        .style("text-anchor", "end");

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(${margin.left},0)`)
        .call(d3.axisLeft(y));

    svg.append("text")
        .attr("x", margin.left)
        .attr("y", 22)
        .attr("fill", "#cbd5e1")
        .attr("font-size", 14)
        .text(`${player} - ${getShotViewLabel(shotView)} po udaljenosti`);

    svg.selectAll(".distance-bar")
        .data(data, d => d.distance)
        .join("rect")
        .attr("class", "distance-bar")
        .attr("x", d => x(d.distance))
        .attr("width", x.bandwidth())
        .attr("y", height - margin.bottom)
        .attr("height", 0)
        .attr("rx", 6)
        .attr("fill", color)
        .attr("opacity", 0.85)
        .on("mouseover", function(event, d) {
            showTooltip(event, `
                <strong>${player}</strong><br>
                Udaljenost: ${d.distance}<br>
                Broj prikazanih šuteva: ${d.count}<br>
                Pogoci: ${d.made}<br>
                Promašaji: ${d.missed}<br>
                Postotak: ${d.percentage.toFixed(1)}%
            `);
        })
        .on("mousemove", moveTooltip)
        .on("mouseleave", hideTooltip)
        .transition()
        .duration(700)
        .attr("y", d => y(d.count))
        .attr("height", d => height - margin.bottom - y(d.count));
}

// LINE CHART
function drawLineChart(player1, player2) {
    const svg = d3.select("#lineChart");

    svg.selectAll("*").remove();

    const width = 760;
    const height = 420;

    svg.attr("viewBox", `0 0 ${width} ${height}`);

    const players = [
        { player: player1, color: "#38bdf8" },
        { player: player2, color: "#f97316" }
    ];

    const data = players.map(p => ({
        ...p,
        values: [1, 2, 3, 4].map(q => {
            const shots = allData.filter(d =>
                d.PLAYER_NAME === p.player &&
                d.QUARTER === q
            );

            const made = shots.filter(d => d.SHOT_MADE).length;

            return {
                quarter: q,
                value: shots.length ? (made / shots.length) * 100 : 0,
                attempts: shots.length,
                made
            };
        })
    }));

    const x = d3.scalePoint()
        .domain([1, 2, 3, 4])
        .range([80, 720]);

    const y = d3.scaleLinear()
        .domain([0, 100])
        .range([340, 50]);

    svg.append("g")
        .attr("transform", "translate(0,340)")
        .attr("class", "axis")
        .call(d3.axisBottom(x).tickFormat(d => `${d}.`));

    svg.append("g")
        .attr("transform", "translate(80,0)")
        .attr("class", "axis")
        .call(d3.axisLeft(y).tickFormat(d => `${d}%`));

    svg.append("text")
        .attr("x", 80)
        .attr("y", 25)
        .attr("fill", "#cbd5e1")
        .attr("font-size", 14)
        .text("3PT% po četvrtinama - svi pokušaji");

    const legend = svg.append("g")
        .attr("transform", "translate(560,35)");

    players.forEach((p, i) => {
        legend.append("circle")
            .attr("cx", 0)
            .attr("cy", i * 24)
            .attr("r", 6)
            .attr("fill", p.color);

        legend.append("text")
            .attr("x", 14)
            .attr("y", i * 24 + 5)
            .attr("fill", "white")
            .attr("font-size", 13)
            .text(p.player);
    });

    const line = d3.line()
        .x(d => x(d.quarter))
        .y(d => y(d.value))
        .curve(d3.curveMonotoneX);

    data.forEach(playerData => {
        svg.append("path")
            .datum(playerData.values)
            .attr("fill", "none")
            .attr("stroke", playerData.color)
            .attr("stroke-width", 4)
            .attr("d", line);

        svg.selectAll(`.line-dot-${playerData.player.replaceAll(" ", "-")}`)
            .data(playerData.values)
            .enter()
            .append("circle")
            .attr("cx", d => x(d.quarter))
            .attr("cy", d => y(d.value))
            .attr("r", 5)
            .attr("fill", playerData.color)
            .on("mouseover", function(event, d) {
                showTooltip(event, `
                    <strong>${playerData.player}</strong><br>
                    Četvrtina: ${d.quarter}<br>
                    Pokušaji: ${d.attempts}<br>
                    Pogoci: ${d.made}<br>
                    Postotak: ${d.value.toFixed(1)}%
                `);
            })
            .on("mousemove", moveTooltip)
            .on("mouseleave", hideTooltip);
    });
}

// STATS
function updateStats(shots1, shots2, player1, player2) {

    const made1 = shots1.filter(d => d.SHOT_MADE).length;
    const made2 = shots2.filter(d => d.SHOT_MADE).length;

    const pct1 = shots1.length ? (made1 / shots1.length) * 100 : 0;
    const pct2 = shots2.length ? (made2 / shots2.length) * 100 : 0;

    d3.select("#p1Stats").text(`${pct1.toFixed(1)}%`);
    d3.select("#p2Stats").text(`${pct2.toFixed(1)}%`);

    d3.select("#bestZone").text(
        pct1 > pct2 ? player1 : player2
    );
}

// ANIMATION
function toggleAnimation() {

    const btn = d3.select("#playBtn");

    if (playing) {
        clearInterval(timer);
        playing = false;
        btn.text("Pokreni animaciju");
        return;
    }

    playing = true;
    btn.text("Zaustavi animaciju");

    const quarters = ["all", "1", "2", "3", "4"];
    let i = 0;

    timer = setInterval(() => {
        d3.select("#quarter").property("value", quarters[i]);
        update();

        i = (i + 1) % quarters.length;
    }, 1400);
}

// SAMPLE
function sample(data, max) {
    if (data.length <= max) {
        return data;
    }

    const step = Math.ceil(data.length / max);

    return data
        .filter((_, i) => i % step === 0)
        .slice(0, max);
}

// TOOLTIP
function showTooltip(event, html) {
    tooltip
        .html(html)
        .style("opacity", 1);

    moveTooltip(event);
}

function moveTooltip(event) {
    tooltip
        .style("left", `${event.pageX + 14}px`)
        .style("top", `${event.pageY - 20}px`);
}

function hideTooltip() {
    tooltip.style("opacity", 0);
}